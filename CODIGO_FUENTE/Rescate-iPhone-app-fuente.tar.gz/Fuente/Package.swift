// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "RescateiPhone",
    platforms: [.macOS("26.0")],
    targets: [
        .executableTarget(
            name: "RescateiPhone",
            path: "Sources/RescateiPhone",
            swiftSettings: [.swiftLanguageMode(.v5)]
        )
    ]
)
