import SwiftUI
import UserNotifications

enum Paso: Int, CaseIterable, Identifiable {
    case caso, recuperacion, descarga, numero, rescate, arranque
    var id: Int { rawValue }
    var titulo: String {
        switch self {
        case .caso: "Comprobar tu caso"
        case .recuperacion: "Modo recuperación"
        case .descarga: "Bajar el iOS"
        case .numero: "Calcular el número"
        case .rescate: "Rescatar"
        case .arranque: "Primer arranque"
        }
    }
    var simbolo: String {
        switch self {
        case .caso: "magnifyingglass"
        case .recuperacion: "iphone.gen3"
        case .descarga: "icloud.and.arrow.down"
        case .numero: "function"
        case .rescate: "lifepreserver"
        case .arranque: "power"
        }
    }
}

enum Estado { case pendiente, activo, hecho, fallo }
enum TipoLinea { case info, ok, aviso, error }
struct Linea: Identifiable { let id = UUID(); let hora = Date(); let texto: String; let tipo: TipoLinea }
enum Hoja: String, Identifiable { case guia, porque, creditos, confirmar; var id: String { rawValue } }

@MainActor
final class Rescate: ObservableObject {
    static let compartido = Rescate()

    let simulacion: Bool
    let auto: Bool
    let trabajo: URL

    @Published var estados: [Paso: Estado] = Dictionary(uniqueKeysWithValues: Paso.allCases.map { ($0, .pendiente) })
    @Published var actual: Paso = .caso
    @Published var lineas: [Linea] = []
    @Published var progreso: Double? = nil
    @Published var progresoTexto = ""
    @Published var ocupado = false
    @Published var detalle = ""
    @Published var aviso: String? = nil       // aviso naranja en el panel derecho
    @Published var hoja: Hoja? = nil
    @Published var enRescate = false
    @Published var terminado = false          // todo el proceso acabó bien
    @Published var momentoClave = false
    @Published var puedeReintentarMas = false
    @Published var valor: Int? = nil

    private var log: URL?
    private var build: String?
    private var numeros: NumerosEspacio?
    private var ipsw: URL?
    private var iphone: IPhoneRec?
    private var extra = 0
    private var sondeo: Task<Void, Never>?
    private let restore = Proceso()
    private var actividad: NSObjectProtocol?
    private var confirmadoSinBorrar = false

    init() {
        let args = CommandLine.arguments
        simulacion = args.contains("--simulacion") || args.contains("--simulacion-auto")
        auto = args.contains("--simulacion-auto")
        trabajo = Motor.carpetaTrabajo(simulacion: args.contains("--simulacion") || args.contains("--simulacion-auto"))
    }

    // MARK: utilidades
    func decir(_ t: String, _ tipo: TipoLinea = .info) { lineas.append(Linea(texto: t, tipo: tipo)) }
    func poner(_ p: Paso, _ e: Estado) { estados[p] = e }
    func ir(a p: Paso) { actual = p; poner(p, .activo); aviso = nil }

    func avisar(_ titulo: String, _ cuerpo: String) {
        let c = UNMutableNotificationContent(); c.title = titulo; c.body = cuerpo; c.sound = .default
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: UUID().uuidString, content: c, trigger: nil))
    }

    // MARK: arranque
    func empezar() {
        decir(simulacion ? "MODO SIMULACIÓN: nada de esto toca un iPhone de verdad." : "Hola. Voy a ayudarte a actualizar tu iPhone sin borrar nada.", simulacion ? .aviso : .info)
        decir("Empiezo mirando, solo mirando, los registros que dejó Finder. No toco nada.")
        if let a = CommandLine.arguments.first(where: { $0.hasPrefix("--abrir=") }) { hoja = Hoja(rawValue: String(a.dropFirst(8))) }
        Task { await comprobarCaso() }
    }

    // MARK: 1. caso
    func comprobarCaso() async {
        guard !ocupado else { return }
        ocupado = true; defer { ocupado = false }
        sondeo?.cancel()
        ir(a: .caso); aviso = nil
        let env = ProcessInfo.processInfo.environment["RESCATE_SIM_LOGS"]
        let d = (simulacion && env != nil) ? Motor.diagnosticar(carpetaLogs: URL(fileURLWithPath: env!)) : Motor.diagnosticar()
        switch d {
        case .sinRegistros:
            poner(.caso, .fallo)
            aviso = "No encuentro registros de una actualización fallida. Intenta «Actualizar» una vez en Finder (con el iPhone en recuperación) y vuelve a pulsar «Comprobar otra vez»."
            decir("No encuentro registros en «iPhone Updater Logs».", .aviso)
        case .otroError(let m):
            poner(.caso, .fallo)
            aviso = "Tu error parece ser otro. Este arreglo NO sirve para él, así que no sigas."
            decir(m, .error)
        case .esTuCaso(let l, let b, let n):
            log = l; build = b; numeros = n
            decir("Encontrado «Failed preallocation due to space»: es EXACTAMENTE este problema. 🎯", .ok)
            if let n { decir("Finder necesitaba \(n.necesario) MB y había \(n.libre) MB libres.") }
            if let b { decir("La actualización que falló era la versión (build) \(b).", .ok) }
            poner(.caso, .hecho)
            ir(a: .recuperacion)
            decir("Ahora pon el iPhone en modo recuperación (mira el dibujo). Yo lo busco solo cada pocos segundos.")
            empezarSondeo()
        }
    }

    // MARK: 2. recuperación
    func empezarSondeo() {
        sondeo?.cancel()
        sondeo = Task { [weak self] in
            var avisado = false
            while !Task.isCancelled {
                guard let self, self.actual == .recuperacion else { return }
                if let r = await Motor.buscarIPhone(simulacion: self.simulacion) {
                    self.iphone = r
                    self.decir("iPhone encontrado en modo \(r.modo): \(r.producto). (El número de serie lo mantengo oculto.)", .ok)
                    self.poner(.recuperacion, .hecho)
                    self.ir(a: .descarga)
                    self.decir("Siguiente: bajar de Apple el iOS correcto para tu modelo (unos 13 GB).")
                    if self.auto { Task { await self.descargar() } }
                    return
                } else if !avisado {
                    avisado = true
                    self.aviso = "Todavía no veo ningún iPhone en modo recuperación. Conéctalo directo al Mac con el cable y sigue el dibujo."
                    self.decir("Todavía no veo el iPhone. Conéctalo y ponlo así: subir volumen · bajar volumen · mantener botón lateral hasta ver el cable y el ordenador.", .aviso)
                }
                try? await Task.sleep(for: .seconds(2))
            }
        }
    }

    func buscarAhora() {
        Task {
            if let r = await Motor.buscarIPhone(simulacion: simulacion) { _ = r; sondeo?.cancel(); empezarSondeo() }
            else { decir("Sigo sin ver el iPhone. Prueba otro cable o otro puerto, directo al Mac (sin hub).", .aviso) }
        }
    }

    // MARK: 3. descarga
    func descargar() async {
        guard !ocupado, let iphone else { return }
        ocupado = true; defer { ocupado = false; progreso = nil; progresoTexto = "" }
        aviso = nil
        do {
            decir("Pregunto a Apple (vía ipsw.me) qué iOS firma para \(iphone.producto)…")
            let fw = try await Motor.firmwareFirmado(producto: iphone.producto, build: build, simulacion: simulacion)
            if let b = build, b != fw.build { decir("Apple ya no firma \(b); uso \(fw.version) (\(fw.build)), que es más nueva.", .aviso) }
            let destino = trabajo.appendingPathComponent("IPSW/\(fw.url.lastPathComponent)")
            let parcial = destino.appendingPathExtension("parte")
            ipsw = destino

            if simulacion {
                try await descargaSimulada(fw, destino)
            } else {
                if FileManager.default.fileExists(atPath: destino.path), await verificar(destino, fw) {
                    decir("Ya estaba descargado y comprobado: \(destino.lastPathComponent).", .ok)
                } else {
                    try? FileManager.default.removeItem(at: destino)
                    let libre = Motor.espacioLibre(en: trabajo), ya = Motor.tamano(parcial)
                    if libre + ya < fw.tam + 2_000_000_000 {
                        throw ErrorRescate.msg("Falta espacio en el Mac: necesito \(fw.tam / 1_000_000_000 + 2) GB y hay \(libre / 1_000_000_000) GB libres. Si el Mac está actualizándose, cancela esa actualización.")
                    }
                    decir("Descargando iOS \(fw.version) (\(fw.build)) de Apple: \(fw.tam / 1_000_000) MB. Si se corta, vuelve a pulsar y sigo donde me quedé.")
                    try await bajar(fw, parcial: parcial)
                    try? FileManager.default.removeItem(at: destino)
                    try FileManager.default.moveItem(at: parcial, to: destino)
                    guard await verificar(destino, fw) else {
                        try? FileManager.default.removeItem(at: destino)
                        throw ErrorRescate.msg("El archivo descargado está dañado (la huella no coincide). Lo he borrado; pulsa de nuevo para bajarlo otra vez.")
                    }
                }
            }
            decir("Descargado y comprobado. ✅", .ok)
            poner(.descarga, .hecho)
            avisar("Descarga terminada", "El iOS ya está en tu Mac y comprobado. Vuelve a la app para seguir.")
            try await prepararNumero(destino)
        } catch let e as ErrorRescate {
            poner(.descarga, .fallo); aviso = e.texto; decir(e.texto, .error)
        } catch {
            poner(.descarga, .fallo); aviso = "No pude hacerlo: \(error.localizedDescription)"; decir(aviso!, .error)
        }
    }

    private func bajar(_ fw: Firmware, parcial: URL) async throws {
        let p = Proceso()
        let tam = fw.tam
        let vigia = Task { [weak self] in
            while !Task.isCancelled {
                let t = Motor.tamano(parcial)
                self?.progreso = tam > 0 ? min(Double(t) / Double(tam), 1) : nil
                self?.progresoTexto = String(format: "%.1f de %.1f GB", Double(t) / 1e9, Double(tam) / 1e9)
                try? await Task.sleep(for: .milliseconds(500))
            }
        }
        defer { vigia.cancel() }
        if Motor.tamano(parcial) < fw.tam || fw.tam == 0 {
            let (code, _) = await p.correr("/usr/bin/curl", ["-fL", "--proto", "=https", "-C", "-", "--retry", "5", "--retry-delay", "5", "-o", parcial.path, fw.url.absoluteString], acumular: false)
            if code != 0 { throw ErrorRescate.msg("La descarga se cortó (código \(code)). Pulsa «Descargar» otra vez y seguirá donde se quedó.") }
        }
    }

    private func verificar(_ url: URL, _ fw: Firmware) async -> Bool {
        decir("Compruebo que el archivo no está dañado (huella SHA1)…")
        progresoTexto = "Comprobando…"
        let h = await Task.detached { Motor.sha1(de: url) { p in Task { @MainActor in Rescate.compartido.progreso = p } } }.value
        progreso = nil
        return h == fw.sha1
    }

    private func descargaSimulada(_ fw: Firmware, _ destino: URL) async throws {
        decir("(Simulación) Finjo bajar \(fw.tam / 1_000_000) MB…")
        for i in 1...20 {
            progreso = Double(i) / 20; progresoTexto = String(format: "%.1f de %.1f GB", 13.0 * Double(i) / 20, 13.0)
            try? await Task.sleep(for: .milliseconds(auto ? 60 : 250))
        }
        Motor.crearIPSWSimulado(en: destino)
    }

    // MARK: 4. número
    func prepararNumero(_ destino: URL) async throws {
        ir(a: .numero)
        decir("Compruebo que este iOS trae la opción «actualizar sin borrar»…")
        guard await Motor.iosPermiteActualizarSinBorrar(ipsw: destino, simulacion: simulacion) else {
            poner(.numero, .fallo)
            throw ErrorRescate.msg("Este iOS no trae la opción de actualizar sin borrar. Me paro.")
        }
        decir("El iOS tiene la opción «actualizar sin borrar». ✅", .ok)
        let c = try await Motor.calcular(ipsw: destino, numeros: numeros)
        for (k, v) in c.real { decir("Tamaño real del sistema (\(k)): \(v) MiB") }
        decir(c.resumen)
        valor = c.valor + extra
        decir("Número del arreglo: \(valor!). Es lo que le digo al «guardia» del iPhone para que haga limpieza.", .ok)
        poner(.numero, .hecho)
        ir(a: .rescate)
        decir("Todo listo. Cuando quieras, pulsa «Rescatar mi iPhone». Te pediré escribir SI.")
        if auto { Task { try? await Task.sleep(for: .seconds(1)); await self.lanzarRescate() } }
    }

    // MARK: 5. rescate
    func pedirConfirmacion() { hoja = .confirmar }

    func lanzarRescate() async {
        guard !ocupado, !enRescate, let ipsw, let valor else { return }
        hoja = nil; aviso = nil; puedeReintentarMas = false
        ocupado = true; defer { ocupado = false }
        // El iPhone debe seguir ahí
        guard let r = await Motor.buscarIPhone(simulacion: simulacion) else {
            aviso = "No veo el iPhone en modo recuperación. Conéctalo, ponlo en recuperación y pulsa de nuevo."
            decir("No veo el iPhone. No he tocado nada.", .error); return
        }
        iphone = r
        decir("iPhone listo en modo \(r.modo).", .ok)
        if !simulacion {
            _ = await Proceso().correr("/usr/bin/pkill", ["-x", "MobileDeviceUpdater"])
            decir("Cerrada la ventana de actualización de Finder (para que no se pelee).")
        }
        // ---- Protecciones: nunca -e, siempre la variante de actualizar ----
        let variante = "Customer Upgrade Install (IPSW)"
        let args = ["-y", "-P", "-i", r.ecid, "--variant", variante, ipsw.path]
        guard !args.contains("-e"), !args.contains("--erase"), args.contains(variante) else {
            decir("Protección: los argumentos no son seguros. No lanzo nada.", .error); return
        }
        let reg = trabajo.appendingPathComponent("registros/rescate_\(Int(Date().timeIntervalSince1970)).txt")
        FileManager.default.createFile(atPath: reg.path, contents: nil)
        let fh = try? FileHandle(forWritingTo: reg)

        poner(.rescate, .activo); enRescate = true; momentoClave = false; confirmadoSinBorrar = false
        actividad = ProcessInfo.processInfo.beginActivity(options: [.idleSystemSleepDisabled, .userInitiated], reason: "Rescate del iPhone")
        decir("Empiezo. No toques el iPhone ni el cable (unos 10–20 minutos). Registro completo guardado en tu Mac (lleva datos de tu iPhone: no lo compartas).")

        let exe: String, argv: [String]
        if simulacion {
            exe = "/bin/bash"; argv = [Motor.recurso("simulador_idevicerestore.sh")!.path] + args
        } else { exe = Motor.helper("idevicerestore"); argv = args }

        var borro = false
        let esperaEscribir = { (l: String) in fh?.write((l + "\n").data(using: .utf8)!) }
        let (code, _) = await restore.correr(exe, argv, env: ["IDEVICERESTORE_CRYPTEX_SIZE_MIB": String(valor)], acumular: false) { [weak self] l in
            esperaEscribir(l)
            Task { @MainActor in
                guard let self, !borro else { return }
                if self.revisar(l) { borro = true; self.restore.parar() }
            }
        }
        try? fh?.close()
        if let a = actividad { ProcessInfo.processInfo.endActivity(a); actividad = nil }
        enRescate = false
        let texto = Motor.leer(reg) ?? ""
        concluir(codigo: code, texto: texto, borro: borro, reg: reg)
    }

    /// Devuelve true si hay que cortar (iba a borrar).
    private func revisar(_ l: String) -> Bool {
        if l.contains("will erase") || l.contains("Erase Install") || l.contains("erasing all") {
            poner(.rescate, .fallo)
            aviso = "¡El programa iba a BORRAR! Lo he parado antes de empezar. Tus datos siguen ahí."
            decir("¡El programa iba a BORRAR! Lo he parado antes de empezar. Tus datos siguen ahí.", .error)
            return true
        }
        detalle = l.count > 140 ? String(l.prefix(140)) + "…" : l
        if l.contains("without erasing user data") { if !confirmadoSinBorrar { confirmadoSinBorrar = true; decir("Confirmado: actualizará SIN borrar tus datos. ✅", .ok) } }
        else if l.contains("Declaring Cryptex1,SystemOSSize") { decir("Arreglo activo: le he dicho al guardia que el sistema es un poco más grande.", .ok) }
        else if l.contains("Sending Cryptex1,SystemOS now") {
            decir("¡MOMENTO CLAVE SUPERADO! El iPhone aceptó reservar el espacio. Enviando el sistema…", .ok)
            if !momentoClave { momentoClave = true; avisar("¡Momento clave superado!", "El iPhone aceptó el sistema nuevo. Ya lo peor pasó. No lo toques.") }
        }
        else if l.contains("Failed preallocation") { decir("Aviso del iPhone: falta sitio todavía.", .aviso) }
        else if l.contains("Sealing System Volume") { decir("Sellando el sistema… casi está.", .ok) }
        else if l.contains("Status: Restore Finished") { decir("El Mac ha terminado su parte. 🎉", .ok) }
        else if l.contains("ERROR") || l.contains("FAILURE") { decir("Aviso: " + String(l.prefix(160)), .aviso) }
        return false
    }

    private func concluir(codigo: Int32, texto: String, borro: Bool, reg: URL) {
        if borro { return }
        if texto.contains("Status: Restore Finished") {
            poner(.rescate, .hecho)
            ir(a: .arranque)
            decir("La actualización terminó bien. Ahora el iPhone arranca solo: manzana con una barra lenta (10–30 min). NO lo toques.", .ok)
            avisar("¡Rescate terminado!", "Tu iPhone se está reiniciando. Espera a que pida el código; no lo toques.")
        } else if texto.contains("Failed preallocation") {
            poner(.rescate, .fallo); puedeReintentarMas = true
            aviso = "Sigue faltando sitio. Puedes reintentar con un número 200 más alto. El iPhone sigue en recuperación, con tus datos."
            decir(aviso!, .aviso)
        } else if texto.contains("downgrade_check") {
            poner(.rescate, .fallo); aviso = "El iOS descargado es más viejo que el que falló. Hace falta la misma versión o una más nueva."
            decir(aviso!, .error)
        } else if texto.contains("Yonkers") {
            poner(.rescate, .fallo); aviso = "Problema con una pieza interna (libtatsu). Descarga de nuevo la app."
            decir(aviso!, .error)
        } else {
            poner(.rescate, .fallo)
            aviso = "Ha fallado por otro motivo (código \(codigo)). Tus datos no se han borrado. Puedes reintentar."
            decir(aviso!, .error)
            for l in texto.split(separator: "\n").suffix(6) { decir("  " + String(l.prefix(160))) }
        }
    }

    func reintentarMas() { extra += 200; if let v = valor { valor = v + 200 }; poner(.rescate, .activo); puedeReintentarMas = false; aviso = nil; decir("Reintento con el número \(valor ?? 0).") }

    // MARK: 6. arranque
    func todoBien() {
        poner(.arranque, .hecho); terminado = true
        decir("¡Enhorabuena! Tu iPhone está de vuelta. 🎉", .ok)
    }
}
