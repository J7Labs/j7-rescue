import SwiftUI
import UserNotifications

final class Delegado: NSObject, NSApplicationDelegate, UNUserNotificationCenterDelegate {
    func applicationDidFinishLaunching(_ n: Notification) {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
        NSApp.activate(ignoringOtherApps: true)
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ s: NSApplication) -> Bool { true }
    func userNotificationCenter(_ c: UNUserNotificationCenter, willPresent n: UNNotification) async -> UNNotificationPresentationOptions { [.banner, .sound] }
    @MainActor func applicationShouldTerminate(_ s: NSApplication) -> NSApplication.TerminateReply {
        guard Rescate.compartido.enRescate else { return .terminateNow }
        let a = NSAlert()
        a.messageText = "El rescate está en marcha"
        a.informativeText = "Si cierras ahora, se interrumpe a medias. Es mejor esperar a que termine."
        a.addButton(withTitle: "Seguir con el rescate"); a.addButton(withTitle: "Cerrar igualmente")
        return a.runModal() == .alertFirstButtonReturn ? .terminateCancel : .terminateNow
    }
}

@main
struct RescateiPhoneApp: App {
    @NSApplicationDelegateAdaptor(Delegado.self) var delegado
    var body: some Scene {
        WindowGroup("Rescate iPhone") { ContentView(m: Rescate.compartido) }
            .defaultSize(width: 1040, height: 700)
            .windowToolbarStyle(.unified)
    }
}
