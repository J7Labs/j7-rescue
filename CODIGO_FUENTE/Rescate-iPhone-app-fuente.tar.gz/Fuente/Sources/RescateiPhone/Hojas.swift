import SwiftUI

struct HojaMarco<C: View>: View {
    let titulo: String
    @ViewBuilder var contenido: () -> C
    @Environment(\.dismiss) var cerrar
    var body: some View {
        VStack(spacing: 0) {
            HStack { Text(titulo).font(.title2.bold()); Spacer(); Button("Cerrar") { cerrar() }.buttonStyle(.glass).keyboardShortcut(.cancelAction) }.padding(16)
            ScrollView { contenido().padding(.horizontal, 24).padding(.bottom, 24).frame(maxWidth: .infinity, alignment: .leading) }
        }.frame(width: 700, height: 640)
    }
}

func textoRecurso(_ n: String) -> String {
    Motor.recurso(n).flatMap { try? String(contentsOf: $0, encoding: .utf8) } ?? "(No encuentro \(n) dentro de la app.)"
}

struct HojaGuia: View {
    var body: some View {
        HojaMarco(titulo: "Guía") {
            Text("Esta guía explica el método paso a paso. La app hace por ti los pasos de «Terminal» que aparecen en ella.")
                .font(.callout).foregroundStyle(.secondary)
            MarkdownView(texto: textoRecurso("TUTORIAL.md"))
        }
    }
}

struct HojaPorque: View {
    @State private var fase = 0
    let textos = [
        "Tu iPhone es una casa de dos plantas. Arriba está el sistema (iOS). Abajo, tus cosas: fotos, mensajes, apps.",
        "Antes de actualizar, un «guardia» comprueba si el sistema nuevo cabe. Como ibas muy justo, dice: «cabe».",
        "El iPhone quita el sistema viejo. Pero al reservar sitio para el nuevo, el almacenamiento tiene una norma que el guardia no conoce: no se puede reservar de golpe más del ~84 % del espacio libre. No entra… y arriba queda vacío. Abajo no se ha tocado nada.",
        "El arreglo le dice al guardia que el sistema es un poco más grande de lo real. Entonces el guardia dice «no cabe» y el iPhone hace su limpieza de temporales (cachés, registros…). Con ese hueco, el sistema de verdad sí entra.",
    ]
    var body: some View {
        HojaMarco(titulo: "¿Por qué pasa esto?") {
            VStack(alignment: .leading, spacing: 14) {
                Casa(fase: fase).frame(width: 300, height: 300).frame(maxWidth: .infinity)
                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 22))
                HStack { ForEach(0..<4) { i in if i == fase { Button("\(i + 1)") { fase = i }.buttonStyle(.glassProminent) } else { Button("\(i + 1)") { withAnimation { fase = i } }.buttonStyle(.glass) } } }.frame(maxWidth: .infinity)
                Text(textos[fase]).font(.title3).fixedSize(horizontal: false, vertical: true)
                Text("**Riesgo:** la limpieza puede borrar cachés y cosas que se vuelven a descargar. En el caso real no faltó nada. Si falla, el iPhone se queda como estaba (en recuperación, con tus datos) y se puede reintentar.").font(.callout)
                Label("Próximamente: un vídeo que lo explica aquí mismo.", systemImage: "play.rectangle").padding(12).frame(maxWidth: .infinity)
                    .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 14)).foregroundStyle(.secondary)
            }
        }
    }
}

struct HojaCreditos: View {
    @State private var verLicencias = false
    var body: some View {
        HojaMarco(titulo: "Créditos") {
            VStack(alignment: .leading, spacing: 16) {
                VStack(spacing: 8) {
                    if let u = Motor.recurso("j7labs.png"), let i = NSImage(contentsOf: u) {
                        Image(nsImage: i).resizable().scaledToFit().frame(width: 150, height: 150).clipShape(RoundedRectangle(cornerRadius: 28))
                    }
                    Text("Hecho por Jesús con Claude").font(.title3.bold())
                    Text("J7 Labs").foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity)
                persona("Senne (3SENN)", "Creador del arreglo que hace posible todo esto: el parche que declara un tamaño mayor del sistema para que el iPhone haga limpieza. Dominio público (CC0).", "https://github.com/3SENN/iphone-stuck-in-recovery-full-storage")
                persona("Igor Varyvoda", "Su guía explicó el problema y dio el código de error (06A6.0064) que nos llevó hasta el arreglo de Senne. Sin ella no habríamos llegado.", "https://www.varyvoda.com/posts/iphone-error-100-full-storage-without-erasing/")
                persona("El equipo de libimobiledevice", "Nikias Bassen, Martin Szulecki, Joshua Hill y todas las personas que han creado idevicerestore, libirecovery, libimobiledevice, libusbmuxd, libplist, libtatsu y libimobiledevice-glue: años de trabajo voluntario que permiten restaurar iPhones sin iTunes.", "https://libimobiledevice.org")
                Divider()
                Text("Licencias y código fuente").font(.headline)
                Text("«Rescate iPhone» (el código original de esta app) tiene licencia MIT: es gratuita, se puede copiar y cambiar, y se ofrece sin garantía.").font(.callout)
                Text("Esta app lleva dentro idevicerestore (LGPL 2.1 o posterior) con el parche de Senne, y las librerías libirecovery, libimobiledevice, libusbmuxd, libimobiledevice-glue, libplist y libtatsu (LGPL-2.1), además de OpenSSL (Apache-2.0), libzip (BSD-3), xz/liblzma (dominio público/0BSD) y zstd (BSD). Van como archivos separados dentro de la app (Contents/Frameworks), así que puedes sustituirlas. El código fuente exacto, el parche y el modo de reconstruirlo están en la carpeta CODIGO_FUENTE del .dmg y en los enlaces de abajo. Sin ninguna garantía.")
                    .font(.callout).fixedSize(horizontal: false, vertical: true)
                VStack(alignment: .leading, spacing: 4) {
                    Link("idevicerestore (commit 60192e9)", destination: URL(string: "https://github.com/libimobiledevice/idevicerestore/tree/60192e97f87d1bbab5c493684e0a245b0966363f")!)
                    Link("libtatsu", destination: URL(string: "https://github.com/libimobiledevice/libtatsu")!)
                    Link("libirecovery", destination: URL(string: "https://github.com/libimobiledevice/libirecovery")!)
                    Link("libimobiledevice", destination: URL(string: "https://github.com/libimobiledevice/libimobiledevice")!)
                    Link("libusbmuxd", destination: URL(string: "https://github.com/libimobiledevice/libusbmuxd")!)
                    Link("libplist", destination: URL(string: "https://github.com/libimobiledevice/libplist")!)
                    Link("libimobiledevice-glue", destination: URL(string: "https://github.com/libimobiledevice/libimobiledevice-glue")!)
                    Link("El arreglo de Senne (parche CC0)", destination: URL(string: "https://github.com/3SENN/iphone-stuck-in-recovery-full-storage")!)
                }
                HStack {
                    Button("Ver avisos de licencias") { verLicencias.toggle() }.buttonStyle(.glass)
                    Button("Abrir carpeta de licencias") {
                        if let u = Motor.recurso("Licencias") { NSWorkspace.shared.open(u) }
                    }.buttonStyle(.glass)
                }
                if verLicencias { MarkdownView(texto: textoRecurso("AVISOS_LICENCIAS.md")) }
            }
        }
    }
    func persona(_ n: String, _ t: String, _ url: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(n).font(.headline)
            Text(t).fixedSize(horizontal: false, vertical: true)
            Link(url, destination: URL(string: url)!).font(.caption)
        }.padding(12).frame(maxWidth: .infinity, alignment: .leading).glassEffect(.regular, in: RoundedRectangle(cornerRadius: 14))
    }
}
